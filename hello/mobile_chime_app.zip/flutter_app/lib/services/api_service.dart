
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl = 'http://your-django-backend.com/api/chime';

  Future<void> fetchSettings() async {
    final response = await http.get(Uri.parse(baseUrl));
    if (response.statusCode == 200) {
      // Handle the response
    } else {
      throw Exception('Failed to load settings');
    }
  }
}
