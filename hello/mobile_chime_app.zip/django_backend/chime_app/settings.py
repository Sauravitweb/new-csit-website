
# Django settings for the project
