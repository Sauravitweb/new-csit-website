
from django.db import models

class ChimeSettings(models.Model):
    user_id = models.IntegerField(unique=True)
    chime_sound = models.CharField(max_length=100)
    silent_hours = models.CharField(max_length=100)
