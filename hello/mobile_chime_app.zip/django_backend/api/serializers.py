
from rest_framework import serializers
from .models import ChimeSettings

class ChimeSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChimeSettings
        fields = '__all__'
