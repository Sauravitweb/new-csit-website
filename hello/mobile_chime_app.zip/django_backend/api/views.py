
from rest_framework import viewsets
from .models import ChimeSettings
from .serializers import ChimeSettingsSerializer

class ChimeSettingsViewSet(viewsets.ModelViewSet):
    queryset = ChimeSettings.objects.all()
    serializer_class = ChimeSettingsSerializer
