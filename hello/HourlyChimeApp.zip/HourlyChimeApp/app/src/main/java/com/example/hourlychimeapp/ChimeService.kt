
package com.example.hourlychimeapp

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder
import androidx.core.app.NotificationCompat

class ChimeService : Service() {

    private lateinit var mediaPlayer: MediaPlayer

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mediaPlayer = MediaPlayer.create(this, R.raw.your_music_file)
        mediaPlayer.start()

        mediaPlayer.setOnCompletionListener {
            stopSelf()
        }

        val notification = createNotification()
        startForeground(1, notification)

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, "ChimeChannel")
            .setContentTitle("Hourly Chime")
            .setContentText("Chime is running")
            .setSmallIcon(R.drawable.ic_notification)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
